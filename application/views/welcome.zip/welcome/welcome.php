<!DOCTYPE html>
<html>
<head>
    <script
            src="http://code.jquery.com/jquery-2.2.4.min.js"
            integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
            crossorigin="anonymous"></script>
    <link rel='stylesheet' id='theme-my-login-css'
          href='<?php echo base_url(); ?>frontend_assets/wp-content/plugins/theme-my-login/theme-my-login109c.css?ver=6.4.9'
          type='text/css' media='all'/>
    <link rel='stylesheet' id='contact-form-7-css'
          href='<?php echo base_url(); ?>frontend_assets/wp-content/plugins/contact-form-7/includes/css/styles33a6.css?ver=4.9'
          type='text/css' media='all'/>
    <link rel='stylesheet' id='avada-stylesheet-css'
          href='<?php echo base_url(); ?>frontend_assets/wp-content/themes/Avada/assets/css/style.minbb49.css?ver=5.2.2'
          type='text/css' m

    <link rel='stylesheet' id='wpcw-css'
          href='<?php echo base_url(); ?>frontend_assets/wp-content/plugins/contact-widgets/assets/css/style.minf269.css?ver=1.0.1'
          type='text/css' media='all'/>
    <link rel='stylesheet' id='fusion-dynamic-css-css'
          href='<?php echo base_url(); ?>frontend_assets/wp-content/uploads/fusion-styles/fusion-688ea84.css?timestamp=1518150364&amp;ver=4.9.4'
          type='text/css' media='all'/>
    <link rel='stylesheet' id='ssatc-styles-css'
          href='<?php echo base_url(); ?>frontend_assets/wp-content/plugins/storefront-sticky-add-to-cart/assets/css/style3ec8.css?ver=1.1.6'
          type='text/css' media='all'/>


    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
</head>


<body class="page-template-default page page-id-688 fusion-image-hovers fusion-body ltr no-tablet-sticky-header no-mobile-sticky-header no-mobile-slidingbar no-mobile-totop mobile-logo-pos-left layout-wide-mode fusion-top-header menu-text-align-center fusion-woo-product-design-classic mobile-menu-design-modern fusion-show-pagination-text">
<div id="wrapper" class="">
    <div id="home" style="position:relative;top:-1px;"></div>


    <header class="fusion-header-wrapper fusion-header-shadow">
        <div class="fusion-header-v1 fusion-logo-left fusion-sticky-menu- fusion-sticky-logo- fusion-mobile-logo-1 fusion-mobile-menu-design-modern ">
            <div class="fusion-header-sticky-height"></div>
            <div class="fusion-header">
                <div class="fusion-row">
                    <div class="fusion-logo" data-margin-top="20px" data-margin-bottom="20px" data-margin-left="0px"
                         data-margin-right="0px">
                        <a class="fusion-logo-link" href="http://socialmediagainer.com/">
                            <img src="<?php echo base_url(); ?>frontend_assets/wp-content/uploads/2017/09/gainer.png"
                                 width="295" height="40" alt="Social Media Gainer Logo"
                                 class="fusion-logo-1x fusion-standard-logo"/>

                            <img src="<?php echo base_url(); ?>frontend_assets/wp-content/uploads/2017/09/gainer.png"
                                 width="295" height="40" alt="Social Media Gainer Retina Logo"
                                 class="fusion-standard-logo fusion-logo-2x"/>

                            <!-- mobile logo -->
                            <img src="<?php echo base_url(); ?>frontend_assets/wp-content/uploads/2017/09/gainer.png"
                                 width="295" height="40" alt="Social Media Gainer Mobile Logo"
                                 class="fusion-logo-1x fusion-mobile-logo-1x"/>

                            <img src="<?php echo base_url(); ?>frontend_assets/wp-content/uploads/2017/09/gainer.png"
                                 width="295" height="40" alt="Social Media Gainer Mobile Retina Logo"
                                 class="fusion-logo-2x fusion-mobile-logo-2x"/>

                            <!-- sticky header logo -->
                        </a>
                    </div>
                    <nav class="fusion-main-menu" aria-label="Main Menu">
                        <ul role="menubar" id="menu-app-main-menu" class="fusion-menu">
                            <li role="menuitem" id="menu-item-623"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-623"><a
                                        href="#home"><span class="menu-text button-default">HOME</span></a></li>
                            <li role="menuitem" id="menu-item-11"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11"><a
                                        href="#intro"><span class="menu-text">INTRO</span></a></li>
                            <li role="menuitem" id="menu-item-12"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12"><a
                                        href="#features"><span class="menu-text">FEATURES</span></a></li>
                            <li role="menuitem" id="menu-item-13"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13"><a
                                        href="#screenshots"><span class="menu-text">SCREENSHOTS</span></a></li>

                            <li role="menuitem" id="menu-item-654"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-654"><a
                                        href="#contact"><span class="menu-text">CONTACT</span></a></li>

                            <li role="menuitem" id="menu-item-654"
                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-654"><a
                                        href="#contact"><span class="menu-text"></span></a></li>


                        </ul>
                    </nav>
                    <div class="fusion-mobile-menu-icons">
                        <a href="#" class="fusion-icon fusion-icon-bars" aria-label="Toggle mobile menu"></a>


                    </div>

                    <nav class="fusion-mobile-nav-holder fusion-mobile-menu-text-align-left"></nav>

                </div>
            </div>
        </div>
        <div class="fusion-clearfix"></div>
    </header>

    <div id="sliders-container">
    </div>











    <main id="main" role="main" class="clearfix " style="">
        <div class="fusion-row" style="">
            <section id="content" style="width: 100%;">
                <div id="post-688" class="post-688 page type-page status-publish hentry">




                <div align="center" style="background:"> <h2> Social Media Gainer </h2>
                Supercharge your social media profile, and skyrocket your <br> account to the next level. <br><br>

                    <a href="<?php echo base_url();?>login"><span class="menu-text button-default" style="padding: 10px"> Sign in </span></a>

                </div>

                    <br><br><br><br>   <br><br><br><br>
                </div>
            </section>




        </div>  <!-- fusion-row -->
    </main>  <!-- #main -->















    <div class="fusion-footer">

        <footer role="contentinfo"
                class="fusion-footer-widget-area fusion-widget-area fusion-footer-widget-area-center">
            <div class="fusion-row">
                <div class="fusion-columns fusion-columns-1 fusion-widget-area">

                    <div class="fusion-column fusion-column-last col-lg-12 col-md-12 col-sm-12">
                    </div>

                    <div class="fusion-clearfix"></div>
                </div> <!-- fusion-columns -->
            </div> <!-- fusion-row -->
        </footer> <!-- fusion-footer-widget-area -->










        <footer id="footer" class="fusion-footer-copyright-area fusion-footer-copyright-center">
            <div class="fusion-row">
                <div class="fusion-copyright-content">

                    <div class="fusion-copyright-notice">
                        <div>
                            © Copyright 2012 - 2018

                                 |   ALL
                            RIGHTS RESERVED   |   POWERED BY <a href='#' >HYPERTEXT SOLUTIONS</a></div>
                    </div>
                    <div class="fusion-social-links-footer">
                        <div class="fusion-social-networks boxed-icons">
                            <div class="fusion-social-networks-wrapper"><a
                                        class="fusion-social-network-icon fusion-tooltip fusion-facebook fusion-icon-facebook"
                                        style="color:#858a9f;background-color:#5a617a;border-color:#5a617a;border-radius:50%;"
                                        href="#" target="" rel="noopener noreferrer" data-placement="top"
                                        data-title="Facebook" data-toggle="tooltip" title="Facebook"><span
                                            class="screen-reader-text">Facebook</span></a><a
                                        class="fusion-social-network-icon fusion-tooltip fusion-twitter fusion-icon-twitter"
                                        style="color:#858a9f;background-color:#5a617a;border-color:#5a617a;border-radius:50%;"
                                        href="#" target="" rel="noopener noreferrer" data-placement="top"
                                        data-title="Twitter" data-toggle="tooltip" title="Twitter"><span
                                            class="screen-reader-text">Twitter</span></a><a
                                        class="fusion-social-network-icon fusion-tooltip fusion-linkedin fusion-icon-linkedin"
                                        style="color:#858a9f;background-color:#5a617a;border-color:#5a617a;border-radius:50%;"
                                        href="#" target="" rel="noopener noreferrer" data-placement="top"
                                        data-title="Linkedin" data-toggle="tooltip" title="Linkedin"><span
                                            class="screen-reader-text">Linkedin</span></a><a
                                        class="fusion-social-network-icon fusion-tooltip fusion-instagram fusion-icon-instagram"
                                        style="color:#858a9f;background-color:#5a617a;border-color:#5a617a;border-radius:50%;"
                                        href="#" target="" rel="noopener noreferrer" data-placement="top"
                                        data-title="Instagram" data-toggle="tooltip" title="Instagram"><span
                                            class="screen-reader-text">Instagram</span></a></div>
                        </div>
                    </div>

                </div> <!-- fusion-fusion-copyright-content -->
            </div> <!-- fusion-row -->
        </footer> <!-- #footer -->
    </div> <!-- fusion-footer -->
</div> <!-- wrapper -->

<a class="fusion-one-page-text-link fusion-page-load-link"></a>


<script type='text/javascript'
        src='<?php echo base_url(); ?>frontend_assets/wp-content/plugins/contact-form-7/includes/js/scripts33a6.js?ver=4.9'></script>
<script type='text/javascript'
        src='<?php echo base_url(); ?>frontend_assets/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70'></script>
<!--[if IE 9]>
<![endif]-->


</body>


</html>


