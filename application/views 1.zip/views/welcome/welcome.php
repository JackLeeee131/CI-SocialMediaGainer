<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <?php
    $page_name = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    if($page_name == 'socialmediagainer') {
        $page_name = 'welcome';
    }
    $get_titles = $this->common_model->get_table_data('tbl_website_keywords','page_title',array('page_name' => $page_name));
    ?>


    <title> <?php if(!empty($get_titles[0]['page_title'])) { echo $get_titles[0]['page_title']; } else { echo 'Social Media Gainer'; } ?> </title>


    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url(); ?>assets/dist/css_landing_page/bootstrap.min.css" rel="stylesheet">

    <!-- Fontawesome CSS -->
    <link href="<?php echo base_url(); ?>assets/css/font-awesome.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url(); ?>assets/css/landing-style.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/responsive.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css" rel="stylesheet">



</head>

<body>

<!-- ***** Header Area Start ***** -->
<header class="header_area animated">
    <div class="container-fluid">
        <div class="row align-items-center">
            <!-- Menu Area Start -->
            <div class="col-12 col-lg-10">
                <div class="menu_area">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <!-- Logo -->
                        <a class="navbar-brand" href="#"><span class="front_logo_text"><img src="<?php echo base_url(); ?>assets/img/gainer-logo.png" alt="" class="front_logo"/> Social Media Gainer</span></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ca-navbar" aria-controls="ca-navbar" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <!-- Menu Area -->
                        <div class="collapse navbar-collapse" id="ca-navbar">
                            <ul class="navbar-nav ml-auto" id="nav">
                                <li class="nav-item active"><a class="nav-link" href="#home">Home</a></li>
                                <li class="nav-item"><a class="nav-link" href="#about">Intro</a></li>
                                <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
                                <li class="nav-item"><a class="nav-link" href="#screenshot">Screenshot</a></li>
                                <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                            </ul>
                            <div class="sing-up-button d-lg-none">
                                <a href="<?php echo base_url(); ?>login/signup">Sign Up</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
            <!-- Signup btn -->
            <div class="col-12 col-lg-2">
                <div class="sing-up-button d-none d-lg-block">
                    <a href="<?php echo base_url(); ?>login/signup">Sign Up</a>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- ***** Header Area End ***** -->

<!-- ***** Wellcome Area Start ***** -->
<section class="wellcome_area clearfix" id="home">
    <div class="container h-100">
        <div class="row h-100 align-items-center text-center">
            <div class="col-12 col-md">
                <div class="wellcome-heading">
                    <h2>Social Media Gainer</h2>
                    <h3>SMG</h3>
                    <p>Supercharge your social media profile, and skyrocket your account to the next level.</p>
                </div>
                <div class="get-start-area">
                    <a href="<?php echo base_url(); ?>login/signup" class="btn">Sign Up</a>
                    <a href="<?php echo base_url(); ?>login" class="btn">Sign In</a>
                </div>
            </div>
        </div>
    </div>

</section>
<!-- ***** Wellcome Area End ***** -->

<!-- ***** Special Area Start ***** -->
<section class="special-area bg-white section_padding_100" id="about">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- Section Heading Area -->
                <div class="section-heading text-center">
                    <h2>All About Avada App</h2>
                    <div class="line-shape"></div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Single Special Area -->
            <div class="col-12 col-md-4">
                <div class="single-special text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="single-icon">
                        <i class="ti-mobile" aria-hidden="true"></i>
                    </div>
                    <h4>Easy to use</h4>
                    <p>Pellentesque accumsan ac elit vel lobortis. Etiam eu nisl sit amet libero porta lacinia. Vestibulum ante ipsum primis</p>
                </div>
            </div>
            <!-- Single Special Area -->
            <div class="col-12 col-md-4">
                <div class="single-special text-center wow fadeInUp" data-wow-delay="0.4s">
                    <div class="single-icon">
                        <i class="ti-ruler-pencil" aria-hidden="true"></i>
                    </div>
                    <h4>Powerful Design</h4>
                    <p>Pellentesque accumsan ac elit vel lobortis. Etiam eu nisl sit amet libero porta lacinia. Vestibulum ante ipsum primis</p>
                </div>
            </div>
            <!-- Single Special Area -->
            <div class="col-12 col-md-4">
                <div class="single-special text-center wow fadeInUp" data-wow-delay="0.6s">
                    <div class="single-icon">
                        <i class="ti-settings" aria-hidden="true"></i>
                    </div>
                    <h4>Customizability</h4>
                    <p>Pellentesque accumsan ac elit vel lobortis. Etiam eu nisl sit amet libero porta lacinia. Vestibulum ante ipsum primis</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Special Description Area -->
    <div class="special_description_area mt-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="special_description_img">
                        <img src="<?php echo base_url(); ?>assets/img/bg-img/special.png" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-xl-5 ml-xl-auto">
                    <div class="special_description_content">
                        <h2>We Make Your life Easier</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                        <div class="app-download-area">
                            <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
                                <!-- Google Store Btn -->
                                <a href="#">
                                    <i class="fa fa-android"></i>
                                    <p class="mb-0"><span>available on</span> Google Store</p>
                                </a>
                            </div>
                            <div class="app-download-btn wow fadeInDown" data-wow-delay="0.4s">
                                <!-- Apple Store Btn -->
                                <a href="#">
                                    <i class="fa fa-apple"></i>
                                    <p class="mb-0"><span>available on</span> Apple Store</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Special Description Area -->
    <div class="pricing-plane-area section_padding_100">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-5 ml-xl-auto">
                    <div class="special_description_content">
                        <h2>Live Stats Anywhere</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                        <div class="app-download-area">
                            <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
                                <!-- Google Store Btn -->
                                <a href="#">
                                    <i class="fa fa-android"></i>
                                    <p class="mb-0"><span>available on</span> Google Store</p>
                                </a>
                            </div>
                            <div class="app-download-btn wow fadeInDown" data-wow-delay="0.4s">
                                <!-- Apple Store Btn -->
                                <a href="#">
                                    <i class="fa fa-apple"></i>
                                    <p class="mb-0"><span>available on</span> Apple Store</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="special_description_img">
                        <img src="<?php echo base_url(); ?>assets/img/bg-img/special.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ***** Special Area End ***** -->

<!-- ***** Cool Facts Area Start ***** -->
<section class="cool_facts_area clearfix">
    <div class="container">
        <div class="row">

            <div class="col-lg-6">
                <div class="special_description_img">
                    <img src="<?php echo base_url(); ?>assets/img/bg-img/special.png" alt="">
                </div>
            </div>

            <div class="col-lg-6 col-xl-5 ml-xl-auto">
                <div class="special_description_content">
                    <h2 style="color: #FFF;">Beautiful User Interface</h2>
                    <p style="color: #FFF;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                    <div class="app-download-area">
                        <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
                            <!-- Google Store Btn -->
                            <a href="#">
                                <i class="fa fa-android"></i>
                                <p class="mb-0"><span>available on</span> Google Store</p>
                            </a>
                        </div>
                        <div class="app-download-btn wow fadeInDown" data-wow-delay="0.4s">
                            <!-- Apple Store Btn -->
                            <a href="#">
                                <i class="fa fa-apple"></i>
                                <p class="mb-0"><span>available on</span> Apple Store</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- ***** Cool Facts Area End ***** -->

<!-- ***** App Screenshots Area Start ***** -->
<section class="app-screenshots-area bg-white section_padding_0_100 clearfix" id="screenshot">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <!-- Heading Text  -->
                <div class="section-heading">
                    <h2>Screenshot Candy</h2>
                    <div class="line-shape"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <!-- App Screenshots Slides  -->
                <div class="app_screenshots_slides owl-carousel">
                    <div class="single-shot">
                        <img src="<?php echo base_url(); ?>assets/img/scr-img/app-1.jpg" alt="">
                    </div>
                    <div class="single-shot">
                        <img src="<?php echo base_url(); ?>assets/img/scr-img/app-2.jpg" alt="">
                    </div>
                    <div class="single-shot">
                        <img src="<?php echo base_url(); ?>assets/img/scr-img/app-3.jpg" alt="">
                    </div>
                    <div class="single-shot">
                        <img src="<?php echo base_url(); ?>assets/img/scr-img/app-4.jpg" alt="">
                    </div>
                    <div class="single-shot">
                        <img src="<?php echo base_url(); ?>assets/img/scr-img/app-5.jpg" alt="">
                    </div>
                    <div class="single-shot">
                        <img src="<?php echo base_url(); ?>assets/img/scr-img/app-3.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ***** App Screenshots Area End *****======


<!-- ***** Contact Us Area Start ***** -->
<section class="footer-contact-area section_padding_100 clearfix" id="contact">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <!-- Heading Text  -->
                <div class="section-heading">
                    <h2>Get In Touch With Us!</h2>
                    <div class="line-shape"></div>
                </div>
                <div class="footer-text">
                    <p>We'll send you epic weekly blogs, whitepapers and things to make your app startup thrive, all FREE!</p>
                </div>
                <div class="address-text">
                    <p><span>Address:</span> 40 Baria Sreet 133/2 NewYork City, US</p>
                </div>
                <div class="phone-text">
                    <p><span>Phone:</span> +11-225-888-888-66</p>
                </div>
                <div class="email-text">
                    <p><span>Email:</span> info@scoialmediagainer.com</p>
                </div>
            </div>
            <div class="col-md-6">
                <!-- Form Start-->
                <div class="contact_from">
                    <form action="#" method="post">
                        <!-- Message Input Area Start -->
                        <div class="contact_input_area">
                            <div class="row">
                                <!-- Single Input Area Start -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="name" id="name" placeholder="Your Name" required>
                                    </div>
                                </div>
                                <!-- Single Input Area Start -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email" id="email" placeholder="Your E-mail" required>
                                    </div>
                                </div>
                                <!-- Single Input Area Start -->
                                <div class="col-12">
                                    <div class="form-group">
                                        <textarea name="message" class="form-control" id="message" cols="30" rows="4" placeholder="Your Message *" required></textarea>
                                    </div>
                                </div>
                                <!-- Single Input Area Start -->
                                <div class="col-12">
                                    <button type="submit" class="btn submit-btn">Send Now</button>
                                </div>
                            </div>
                        </div>
                        <!-- Message Input Area End -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ***** Contact Us Area End ***** -->

<!-- ***** Footer Area Start ***** -->
<footer class="footer-social-icon text-center section_padding_70 clearfix">
    <!-- footer logo -->
    <div class="footer-text">
        <h2><img src="<?php echo base_url(); ?>assets/img/gainer-logo.png" alt=""/></h2>
    </div>
    <!-- social icon-->
    <div class="footer-social-icon">
        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
        <a href="#"><i class="active fa fa-twitter" aria-hidden="true"></i></a>
        <a href="#"> <i class="fa fa-instagram" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
    </div>
    <div class="footer-menu">
        <nav>
            <ul>
                <li><a href="#">About</a></li>
                <li><a href="#">Terms &amp; Conditions</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
    </div>
    <!-- Foooter Text-->
    <div class="copyright-text">
        <!-- ***** Removing this text is now allowed! This template is licensed under CC BY 3.0 ***** -->
        <p>Copyright ©2017 Social Media Gainer. All Rights Reserved.</p>
    </div>
</footer>
<!-- ***** Footer Area Start ***** -->


<!-- Jquery-2.2.4 JS -->
<script src="<?php echo base_url(); ?>assets/js/jquery-2.2.4.min.js"></script>
<!-- Popper js -->
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
<!-- Bootstrap-4 Beta JS -->
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<!-- All Plugins JS -->
<script src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
<!-- Slick Slider Js-->
<script src="<?php echo base_url(); ?>assets/js/slick.min.js"></script>
<!-- Footer Reveal JS -->
<script src="<?php echo base_url(); ?>assets/js/footer-reveal.min.js"></script>
<!-- Active JS -->
<script src="<?php echo base_url(); ?>assets/js/active.js"></script>
</body>

</html>
