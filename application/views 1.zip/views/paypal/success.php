<div>
    <h2 style="font-family: 'quicksandbold'; font-size:16px; color:#313131; padding-bottom:8px;">Dear Member</h2>
    <span style="color: #646464;">Your payment was successful, thank you for purchase.</span><br/>
    <span style="color: #646464;">Item Number : 
      	<strong style="font:15px Arial,Helvetica,sans-serif;color:#f09"><?php echo $payment_status; ?></strong>
  	</span><br/>
	<span style="color: #646464;">TXN ID : 
      	<strong style="font:15px Arial,Helvetica,sans-serif;color:#f09"><?php echo $mc_gross; ?></strong>
  	</span><br/>

</div>