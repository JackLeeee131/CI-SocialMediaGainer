<!DOCTYPE html>
<html>
<head>


    <title> Login to Social Media Gainer </title>
    <meta name="description"
          content="Login to Social Media Gainer to boostup social media likes, views, comments, followers">
    <meta name="keywords" content="social media gainer, boost likes, view, comments, followers, packages"/>
    <meta name="subject" content="Social media gainer">
    <meta name="copyright" content="social media gainer">
    <meta name="language" content="US">


    <link href="<?php echo base_url(); ?>frontend_assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Fontawesome CSS -->
    <link href="<?php echo base_url(); ?>frontend_assets/assets/css/font-awesome.min.css" rel="stylesheet">


    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.2/raphael-min.js"></script>
    <script src="<?php echo base_url(); ?>frontend_assets/assets/js/morris.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.js"></script>
    <script src="<?php echo base_url(); ?>frontend_assets/assets/js/example.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>frontend_assets/assets/css/example.css">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>frontend_assets/assets/css/morris.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/iCheck/square/blue.css">
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url(); ?>frontend_assets/assets/css/sb-admin.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>frontend_assets/assets/css/custom.css" rel="stylesheet">
    <link rel='stylesheet prefetch' href='https://daneden.github.io/animate.css/animate.min.css'>


</head>


<body style="overflow: auto; height: 100%; background: rgb(31, 44, 54);">

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#">
        <span class="front_logo_text"><img src="<?php echo base_url(); ?>assets/img/gainer-sign-in-logo.png"
                                           alt="Instagram Login" class="front_logo"/> Social Media Gainer</span></a>
    <a class="second-navbar-toggle"></a>
    <!--    <div class="navbar-options pull-right">
        <ul style="float: right;">
            <li class="no-children">
                <a id="btn-fullscreen" href="#"><i class="fa fa-arrows-alt"></i></a>
            </li>
            <li class="">
                <a style="">
                    <img class="avatar" src="<?php /*echo base_url(); */ ?>frontend_assets/assets/img/flags/en_flag.png">
                    <span>English</span>
                </a>
                <ul tabindex="1000" style="display: none;">
                    <li class="no-children"><a href="#"><img src="<?php /*echo base_url(); */ ?>frontend_assets/assets/img/flags/uk_flag-rounded.png" width="15%"> English </a></li>
                    <li class="no-children"><a href="#"><img src="<?php /*echo base_url(); */ ?>frontend_assets/assets/img/flags/pt_flag-rounded.png" width="15%"> Portuguese</a></li>
                    <li class="no-children"><a href="#"><img src="<?php /*echo base_url(); */ ?>frontend_assets/assets/img/flags/ar_flag-rounded.png" width="15%"> Arabic</a></li>
                </ul>
            </li>
        </ul>
    </div>-->

    <div class="clearfix"></div>
</nav>


<div class="container">

    <div id="LoginDiv" style="display: block;">

        <?php $attributes = array('class' => 'form-signin centered', 'id' => 'login_form');
        echo form_open('login/userlogin', $attributes); ?>

        <h1 class="form-signin-heading">Sign in</h1>


        <?php if ($this->session->flashdata('error_message')) { ?>
            <div class="alert alert-danger ">
                <button class="close" data-close="alert"></button>
                <span><?php echo $this->session->flashdata('error_message'); ?></span>
            </div>
        <?php } ?>
        <?php if ($this->session->flashdata('success_message')) { ?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button>
                <span><?php echo $this->session->flashdata('success_message'); ?></span>
            </div>
        <?php } ?>


        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" name="email" id="inputEmail" class="form-control control" placeholder="Email" required
               autocomplete="off">

        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="password" id="inputPassword" class="form-control control" placeholder="Password"
               required autocomplete="off">


        <!--            <div class="checkbox pull-left">
                        <label>
                            <input type="checkbox" value="remember-me"> Remember me
                        </label>
                    </div>-->

        <div class="pull-right">
            <a class="forget-password" onclick="authAjax('forgot')" style="cursor: pointer">Forgot Password

                <?php
                // $ref =  $this->input->get('ref', TRUE);
                // echo substr($aa, strrpos($aa, '-') + 1)

                ?>


            </a>
        </div>

        <div class="clearfix"></div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in to My Account</button>
        <p>Don't have an account yet ? <a onclick="authAjax('register')">Register </a></p>

        <?php echo form_close(); ?>

    </div><!-- / sign in -->

    <div id="RegisterDiv" style="display: none;">
        <?php $attributes = array('class' => 'form-signin centered', 'id' => 'reg_form');
        echo form_open('login/register', $attributes); ?>
        <h2 class="form-signin-heading">Register</h2>

        <input type="hidden" name="ref_id"
               value="<?php echo substr($this->input->get('ref', TRUE), strrpos($this->input->get('ref', TRUE), '-') + 1) ?>">
        <label for="inputEmail" class="sr-only">Email</label>
        <input type="email" name="reg_email" id="inputEmail" class="form-control control" placeholder="Email" required
               autofocus>

        <label for="inputEmail" class="sr-only">Username (optional)</label>
        <input type="text" name="reg_username" id="inputEmail" class="form-control control" placeholder="Username"
               required autofocus>

        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" minlength="6" name="reg_password" id="password" class="form-control control"
               placeholder="Password" required>

        <label for="inputPassword" class="sr-only">Confirm Password</label>
        <input type="password" minlength="6" name="reg_confirm_password" id="confirm_password" class="form-control control"
               placeholder="Confirm Password" required>

        <span id='pass_validate' style=" font-size: 14px; float: right"></span>

        <div class="checkbox pull-left">
            <label>
                <input type="checkbox" name="terms" id="terms" value="yes"> I Agree to the <a href="#"> Terms and
                    Conditions </a>
            </label>
        </div><!-- / check box

            <div class="pull-right">
                <a href="#" class="forget-password">
                    Re-Send Activation
                </a>
            </div><!-- / forget password-->

        <div class="clearfix"></div>
        <button class="btn btn-lg btn-primary btn-block" type="submit" id="reg_button">Register a New Account</button>
        <p>Already have an account? <a onclick="authAjax('login')">Sign in</a></p>
        <?php echo form_close(); ?>
    </div><!-- / register -->

</div> <!-- /container -->


<script>

    $(document).ready(function () {
        // on form submit
        $("#reg_form").on('submit', function () {
            // to each unchecked checkbox
            if ($('#terms').is(':checked') && $('#password').val() == $('#confirm_password').val()) {
                return true;
            } else {
                if(!$('#terms').is(':checked')) {
                    alert("You must accept the terms and conditions!");
                } else {
                    $('#pass_validate').html('Password Not Matching').css('color', 'red');
                }
                return false;
            }


        })
    });

    $('#password, #confirm_password').on('keyup', function () {
        if ($('#password').val() == $('#confirm_password').val()) {
            $('#pass_validate').html('Matching').css('color', 'green');
        } else
            $('#pass_validate').html('Password Not Matching').css('color', 'red');
    });


</script>


<div class="form-signin white rounded centered form" id="ForgotDiv" style="display:none">
    <h2 class="form-signin-heading">Forgot Password</h2>

    <div id="ForgotPwForm_errors"></div>
    <div id="ForgotPwForm_loading" style="display: none; text-align: center; margin-bottom: 15px;">
    </div>

    <?php $attributes = array('class' => '', 'id' => 'ForgotPwForm');
    echo form_open('login/forgot_password', $attributes); ?>

    <label for="inputPassword" class="sr-only">Password</label>
    <input type="email" name="email" id="email" class="form-control control" autocomplete="off"
           placeholder="Registration Email" required>

    <input type="submit" class="btn btn-lg btn-primary btn-block" id="ForgotPwForm_submit" name="ForgotPwForm_submit"
           value="Submit">
    <?php echo form_close(); ?>

    <p class="txt-center" style="margin-top: 0px;">Remember your password?
        <a onclick="authAjax('login')">Go Back</a>
    </p>
</div>


<div class="form-signin white rounded centered form" id="update_passwordDiv" style="display:none">
    <h2 class="form-signin-heading">Update Password</h2>

    <div id="ForgotPwForm_errors"></div>
    <div id="ForgotPwForm_loading" style="display: none; text-align: center; margin-bottom: 15px;">
    </div>

    <?php $attributes = array('class' => '', 'id' => 'ForgotPwForm');
    echo form_open('login/update_password', $attributes); ?>


    <input type="hidden" name="email" class="form-control control" placeholder="New emaillll"
           value='<?php echo $email; ?>'>


    <label for="inputPassword" class="sr-only">New Password</label>
    <input type="password" minlength="6" name="password" id="inputPassword" class="form-control control"
           placeholder="New Password" required>

    <label for="inputPassword" class="sr-only">Confirm Password</label>
    <input type="password" minlength="6" name="confirm_password" id="inputPassword" class="form-control control"
           placeholder="Confirm Password" required>

    <input type="submit" class="btn btn-lg btn-primary btn-block" id="ForgotPwForm_submit" name="ForgotPwForm_submit"
           value="Update">
    <?php echo form_close(); ?>

    <p class="txt-center" style="margin-top: 0px;">Remember your password?
        <a onclick="authAjax('login')">Go Back</a>
    </p>
</div>


<script type="text/javascript" src="<?php echo base_url(); ?>frontend_assets/assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>frontend_assets/assets/js/drop-down.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>frontend_assets/assets/js/custom.js"></script>

<?php if ($this->session->flashdata('signup')) { ?>
    <script>
        authAjax('register');
    </script>
<?php } ?>


<?php if ($this->session->flashdata('update_password')) { ?>
    <script>
        authAjax('update_password');
    </script>
<?php } ?>

<?php
$ref = $this->input->get('ref', TRUE);
if (!empty($ref)) { ?>
    <script>
        authAjax('register');
    </script>
<?php } ?>

</body>


</html>


